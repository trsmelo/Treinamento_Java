package main;

import entity.Aluno;
import entity.AlunoFormacao;
import entity.Pessoa;
import entity.PessoaFisica;
import entity.PessoaJuridica;

public class Main {
	
	public static void testeAluno() {
		
		Aluno[] alunos = new Aluno[2];

		alunos[0] = new AlunoFormacao(100, "Tiago", "tiago@gmail.com", "quimica", 9., 7.);
		alunos[1] = new AlunoFormacao(200, "Carlos", "carlos@gmail.com", "portugues", 8., 9.);

		alunos[0].gerarMedia();
		alunos[0].gerarSituacao();

		alunos[1].gerarMedia();
		alunos[1].gerarSituacao();
		
		System.out.println(alunos[0].getTipo());
		System.out.println(alunos[0]);
		System.out.println("-------------------------------------------------");
		System.out.println(alunos[1].getTipo());
		System.out.println(alunos[0].getTipo());
	}
	
	public static void testeTipoPessoa() {
		
		Pessoa[] pessoas = new Pessoa[2];
		
		pessoas[0] = new PessoaFisica(001, "tiago", "tiago@gmail.com", "cpf", 1234561);
		pessoas[1] = new PessoaJuridica(002, "carlos", "carlos@gmail.com", "cnpj", 45678989);
		
		System.out.println(pessoas[0].print());
		System.out.println(pessoas[1].print());
	}
	
	public static void main(String[] args) {
		
		//testeAluno();
		testeTipoPessoa();
	}

}
