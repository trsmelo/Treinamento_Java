package persistence;

import java.util.ArrayList;
import java.util.List;

import entity.Produto;
import io.ArquivoLer;

public class ProdutoDao extends Dao {

	public void create(Produto p) throws Exception {

		open();
		stmt = conn.prepareStatement("insert into produto values (seq_produto.nextval,?,?)");
		stmt.setString(1, p.getNome());
		stmt.setDouble(2, p.getPreco());

		stmt.execute();
		close();
	}

	public void planilhaToTabela() throws Exception {
		open();
		ArquivoLer ler = new ArquivoLer();
		ler.open();
		for (Produto x : ler.lerArquivo()) {
			stmt = conn.prepareStatement("insert into produtotemp values (seq_produtotemp.nextval,?,?)");
			stmt.setString(1, x.getNome());
			stmt.setDouble(2, x.getPreco());
			stmt.execute();
			stmt.close();
		}
		ler.close();
		close();
	}

	public List<Produto> listaProdutoFromTable() throws Exception {

		open();
		stmt = conn.prepareStatement("select * from produtotemp");
		rs = stmt.executeQuery();
		List<Produto> produtos = new ArrayList<Produto>();

		while (rs.next()) {
			Produto p = new Produto(rs.getInt(1), rs.getString(2), rs.getDouble(3));

			produtos.add(p);
		}
		close();
		return produtos;
	}

	public List<Produto> listaProduto() throws Exception {

		open();
		stmt = conn.prepareStatement("select * from produto");
		rs = stmt.executeQuery();
		List<Produto> produtos = new ArrayList<Produto>();

		while (rs.next()) {
			Produto p = new Produto(rs.getInt(1), rs.getString(2), rs.getDouble(3));

			produtos.add(p);
		}
		close();
		return produtos;
	}

	public static void main(String[] args) {

		try {

			ProdutoDao pd = new ProdutoDao();
			// Produto p = ;

			pd.planilhaToTabela();

			// pd.listaProduto();

			// pd.listaProdutoFromTable().forEach(x->System.out.println(x));

		} catch (Exception ex) {

			ex.printStackTrace();

		}
	}
}
