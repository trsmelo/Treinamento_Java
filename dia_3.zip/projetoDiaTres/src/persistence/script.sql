conn system/coti;

create user oicoti identified by coti
default tablespace users
quota 100m on users;

grant create table, create view, create procedure, create trigger, 
create sequence, create session to oicoti;

select user from dual;
--system

conn oicoti/coti;

select user from dual;

create table produto (idProduto number (15) primary key,
nome varchar2 (50) not null,
preco number (10,2));

create sequence seq_produto;
	set linesize 2000;
	column nome format a20;
select * from cat;

insert into produtotemp values(seq_produto.nextval,'livro java',100);
insert into produtotemp values(seq_produto.nextval,'livro Oracle',200);
insert into produtotemp values(seq_produto.nextval,'livro Angular',300);
commit;






create table produtotemp as select * from produto where idproduto<0;

create sequence seq_produtotemp;



