package persistence;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

public class Dao {
	
	Connection conn;
	PreparedStatement stmt;
	ResultSet rs;
	
	public void open() throws Exception {
		
		Class.forName("oracle.jdbc.OracleDriver");
		conn = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:XE","oicoti","coti");
	}
	
	public void close() throws Exception {
		conn.close();
	}
	
	public static void main(String[] args) {
		
		try {
			
			Dao dao = new Dao();
			dao.open();
			dao.close();
			System.out.println("Conexao ok");
			
		} catch (Exception ex) {
			ex.printStackTrace();
		}

	}

}
