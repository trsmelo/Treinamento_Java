package entity;

public class AlunoFormacao extends Aluno {

	public AlunoFormacao() {
		super();
	}

	public AlunoFormacao(Integer idAluno, String nome, String email, String disciplina, Double nota1, Double nota2) {
		super(idAluno, nome, email, disciplina, nota1, nota2);
	}

	@Override
	public String getTipo() {

		if (getMedia() != null) {
			if (getMedia() >= 7)
				System.out.println("O aluno se encontra acima da media e regular");
			else {
				System.err.println("O aluno se encontra Irregular.");
			}
			
			return "Resumo do Aluno em Formacao: ";
			
		} else {

			return "Antes calcule a media";

		}
	}
	
	public static void main(String[] args) {
		
		AlunoFormacao af = new AlunoFormacao(1, "Tiago", "tiago@gmail.com", "Prog 2", 8., 8.);
		af.gerarMedia();
		af.gerarSituacao();
		
		System.out.println(af.getTipo());
		System.out.println(af);
	
	}

}
