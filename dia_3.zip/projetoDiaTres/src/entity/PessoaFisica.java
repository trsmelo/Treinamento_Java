package entity;

public class PessoaFisica extends Pessoa{
	
	private Integer cpf;
	
	
	public Integer getCpf() {
		return cpf;
	}

	public void setCpf(Integer cpf) {
		this.cpf = cpf;
	}

	public PessoaFisica() {
		super();

	}

	public PessoaFisica(int id, String nome, String email, String tipoDocumento, int cpf) {
		super(id, nome, email, tipoDocumento);
		this.cpf = cpf;
	}

	@Override
	public String print() {
		if(getTipoDocumento() != null) {
			if(getTipoDocumento() == "cpf" && getCpf() != null)
				
				return "Pessoa Fisica";
			else {
				return "Informe uma pessoa Fisica";				
			}
		}else {
			return "Informe um tipo de documento";
		}
	}

	
}
