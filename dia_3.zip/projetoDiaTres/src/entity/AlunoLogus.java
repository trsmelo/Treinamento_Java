package entity;

public class AlunoLogus extends Aluno {

	public AlunoLogus() {
		super();

	}

	public AlunoLogus(Integer idAluno, String nome, String email, String disciplina, Double nota1, Double nota2) {
		super(idAluno, nome, email, disciplina, nota1, nota2);

	}

	@Override
	public String getTipo() {

		if (getMedia() != null) {
			if (getMedia() >= 9.5)
				System.out.println("O aluno se encontra apto para representar em Provas");
			else if (getMedia() > 8.){
				System.err.println("O aluno se encontra abaixo da Media para representacao.");
				
			} else if (getMedia()>=7.) {
				
				System.out.println("Queda na bolsa de valores");
				
			}

			return "Resumo do Aluno Candidato: ";

		} else {

			return "Antes calcule a media";

		}
	}

}
