package entity;

public class PessoaJuridica extends Pessoa{
	
	private Integer cnpj;

	public Integer getCnpj() {
		return cnpj;
	}

	public void setCnpj(Integer cnpj) {
		this.cnpj = cnpj;
	}

	public PessoaJuridica() {
		super();
	}

	public PessoaJuridica(int id, String nome, String email, String tipoDocumento,Integer cnpj) {
		super(id, nome, email, tipoDocumento);
		this.cnpj = cnpj;
	}
	
	@Override
	public String print() {
		if(getTipoDocumento() != null) {
			if(getTipoDocumento() == "cnpj" && getCnpj() != null)
				
				return "Pessoa Juridica";
			else {
				return "Informe uma pessoa Juridica";				
			}
		}else {
			return "Informe um tipo de documento";
		}
	}	

}
