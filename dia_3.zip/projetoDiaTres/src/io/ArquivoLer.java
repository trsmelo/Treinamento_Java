package io;

import java.io.BufferedReader;
import java.io.FileReader;
import java.util.ArrayList;
import java.util.List;

import entity.Produto;

public class ArquivoLer {

	FileReader fr;
	BufferedReader bf;

	public void open() throws Exception {
		fr = new FileReader("/tmp/planilha.csv");
		bf = new BufferedReader(fr);
	}

	public void close() throws Exception {
		bf.close();
		fr.close();
	}

	public List<Produto> lerArquivo() throws Exception {

		List<Produto> produtos = new ArrayList<Produto>();

		String s = "";
		while ((s = bf.readLine()) != null) {
			String vetor[] = s.split(";");
			Produto p = new Produto();
			p.setIdProduto(new Integer(vetor[0]));
			p.setNome(vetor[1]);
			p.setPreco(new Double(vetor[2]));

			produtos.add(p);

		}
		return produtos;
	}

	public static void main(String[] args) {
		ArquivoLer al = new ArquivoLer();

		try {
			al.open();
			List<Produto> list = al.lerArquivo();
			al.close();
			System.out.println(list);

		} catch (Exception ex) {
			ex.printStackTrace();
		}
	}
}
