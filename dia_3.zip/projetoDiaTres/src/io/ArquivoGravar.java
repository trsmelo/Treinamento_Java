package io;

import java.io.FileWriter;
import java.util.List;

import entity.Produto;
import persistence.ProdutoDao;

public class ArquivoGravar {
	
	FileWriter fw;
	
	public void open() throws Exception{
		fw = new FileWriter("/tmp/planilha.csv",false);
	}
	
	public void close() throws Exception{
		fw.close();
	}
	
	public void gravar(List<Produto> lista)throws Exception{
		for (Produto x : lista) {
			fw.write(x.getIdProduto()+";"+x.getNome()+";"+x.getPreco()+"\n");
		}
		fw.flush();
	}
	
	public static void main(String[] args) {
		try {
			
			ArquivoGravar gr = new ArquivoGravar();
			gr.open();
			gr.gravar(new ProdutoDao().listaProduto());
			gr.close();
			
			System.out.println("Gravacao ok");
			
		} catch (Exception ex) {
			
			ex.printStackTrace();

		}
	}
}
