package entity;

import java.text.NumberFormat;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;

public class Correntista {
	
	private Integer codigo;
	private String nome;
	private LocalDate date;
	private Double saldoCorrentista = 0.0;
	
	private List<Movimentacao> movimentacoes;	
	
	static DateTimeFormatter DTF = DateTimeFormatter.ofPattern("yyyy-MM-dd");
	
	public Correntista() {
	
	}
	
	public Correntista(Integer codigo, String nome, LocalDate date, Double saldoCorrentista) {
	
		this.codigo = codigo;
		this.nome = nome;
		this.date = date;
		this.saldoCorrentista = saldoCorrentista;
	}
		
	public List<Movimentacao> getMovimentacoes() {
		return movimentacoes;
	}

	public void setMovimentacoes(List<Movimentacao> movimentacoes) {
		this.movimentacoes = movimentacoes;
	}

	public Integer getCodigo() {
		return codigo;
	}
	public void setCodigo(Integer codigo) {
		this.codigo = codigo;
	}
	public String getNome() {
		return nome;
	}
	public void setNome(String nome) {
		this.nome = nome;
	}
	public LocalDate getDate() {
		return date;
	}
	public void setDate(LocalDate date) {
		this.date = date;
	}
	public Double getSaldoCorrentista() {
		return saldoCorrentista;
	}
	public void setSaldoCorrentista(Double saldoCorrentista) {
		this.saldoCorrentista = saldoCorrentista;
	}
	
	public void adicionarMovimentacao(Movimentacao m) {
		if(movimentacoes == null) {
			this.movimentacoes = new ArrayList<Movimentacao>();
			
		}if(m.getOperacao().equals("deposito")) {
			setSaldoCorrentista(this.getSaldoCorrentista() + m.getValor());
		
		}else if (m.getOperacao().equals("saque")){
			setSaldoCorrentista(this.getSaldoCorrentista() - m.getValor());
		}
		else {
			System.out.println("Operacao nao encontrada");
		}
		this.movimentacoes.add(m);
	}

	@Override
	public String toString() {
		return "Correntista [codigo=" + codigo + ", nome=" + nome + ", saldoCorrentista=" + saldoCorrentista
				 + "]";
	}
	
	
}
