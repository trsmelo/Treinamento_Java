package entity;

public class Funcionario {
	
	private Integer id;
	private String nome;
	private Integer idade;
	private String sexo;
	private Double salario;
	
	public Funcionario() {
	
	}
	public Funcionario(Integer id, String nome, Integer idade, String sexo, Double salario) {
	
		this.id = id;
		this.nome = nome;
		this.idade = idade;
		this.sexo = sexo;
		this.salario = salario;
	}
	public Integer getId() {
		return id;
	}
	public void setId(Integer id) {
		this.id = id;
	}
	public String getNome() {
		return nome;
	}
	public void setNome(String nome) {
		this.nome = nome;
	}
	public Integer getIdade() {
		return idade;
	}
	public void setIdade(Integer idade) {
		this.idade = idade;
	}
	public String getSexo() {
		return sexo;
	}
	public void setSexo(String sexo) {
		this.sexo = sexo;
	}
	public Double getSalario() {
		return salario;
	}
	public void setSalario(Double salario) {
		this.salario = salario;
	}
	
	@Override
	public String toString() {
		return "Funcionario [id=" + id + ", nome=" + nome + ", idade=" + idade + ", sexo=" + sexo + ", salario="
				+ salario + "]";
	}
	
	
}
