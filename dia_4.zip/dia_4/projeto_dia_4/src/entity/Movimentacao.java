package entity;

import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.util.Date;

public class Movimentacao {
	
	private Integer idMovimentacao;
	private String operacao;
	private Double valor;
	private Date date;
	private Correntista correntista;
	
	//private static SimpleDateFormat SDF = new SimpleDateFormat("yyyy-MM-dd");
	
	
	{
		this.date = new Date();
		
	}
	
	public Movimentacao() {
	
	}

	public Movimentacao(Integer idMovimentacao, String operacao,Double valor, Correntista c) {
	
		this.idMovimentacao = idMovimentacao;
		this.operacao = operacao;
		this.valor = valor;
		this.correntista = c;
	}
	
	public Integer getIdMovimentacao() {
		return idMovimentacao;
	}
	public void setIdMovimentacao(Integer idMovimentacao) {
		this.idMovimentacao = idMovimentacao;
	}
	public String getOperacao() {
		return operacao;
	}
	public void setOperacao(String operacao) {
		this.operacao = operacao;
	}
	public Date getDate() {
		return date;
	}
	public void setDate(Date date) {
		this.date = date;
	}

	public Double getValor() {
		return valor;
	}

	public void setValor(Double valor) {
		this.valor = valor;
	}

	public Correntista getCorrentista() {
		return correntista;
	}

	public void setCorrentista(Correntista correntista) {
		this.correntista = correntista;
	}

	@Override
	public String toString() {
		return "Movimentacao [idMovimentacao=" + idMovimentacao + ", operacao=" + operacao + ", valor=" + valor
				+ ", date=" + date + ", correntista=" + correntista + "]";
	}	
	
	public void gerarMovimentacao() {
		
		if(this.operacao.endsWith("deposito")) {
			this.correntista.setSaldoCorrentista(this.correntista.getSaldoCorrentista() + this.valor);
			
		}else if(this.operacao.endsWith("saque")){
			this.correntista.setSaldoCorrentista(this.correntista.getSaldoCorrentista() - this.valor);
		
		}else {
			System.out.println("Operacao nao encontrada");
		}
		
	}
	
	public static void main(String[] args) {
		
		Correntista c = new Correntista(100, "tiago", LocalDate.of(2019,06,05),1000.);
		Movimentacao m1 = new Movimentacao(01,"deposito",2000.,c);
		Movimentacao m2 = new Movimentacao(02,"deposito",3000.,c);
		Movimentacao m3 = new Movimentacao(03,"saque",1000.,c);
		
		System.out.println("------- Primeira movimentacao ------"+"\n");
		c.adicionarMovimentacao(m1);
		//m1.gerarMovimentacao();
		System.out.println(m1.getCorrentista()+" "+m1);
		System.out.println("\n");
		
		System.out.println("------- Segunda movimentacao ------"+"\n");
		c.adicionarMovimentacao(m2);
		//m2.gerarMovimentacao();
		System.out.println(m2.getCorrentista()+" "+m2);
		System.out.println("\n");
		
		System.out.println("------- Terceira movimentacao ------"+"\n");
		c.adicionarMovimentacao(m3);
		//m2.gerarMovimentacao();
		System.out.println(m3.getCorrentista()+" "+m3);
	}
}
