package Manager;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import entity.Funcionario;

public class ManagerFuncionario {
	
	public static List<Funcionario> funcionarios = new ArrayList<Funcionario>();
	static Map<Boolean,List<Funcionario>> lista;
	
	//mock
	static {
		funcionarios.add(new Funcionario(01, "tiago", 23, "Masc",10000.));
		funcionarios.add(new Funcionario(02, "Carlos", 24, "Masc",20000.));
		funcionarios.add(new Funcionario(03, "Felippe", 25, "Masc",30000.));
		funcionarios.add(new Funcionario(04, "Nayara", 26, "Fem",40000.));
	}
	
	public static void adicionarFuncionario(Funcionario f){
		funcionarios.add(f);
	}
	
	
	public static Map<Boolean,List<Funcionario>> agruparPorSexo(){
		
		Map<Boolean,List<Funcionario>> listaM = funcionarios.stream()
				.collect(Collectors.partitioningBy(c->c.getSexo().equals("Masc")));
		
		return listaM;
	}
	public static Funcionario buscaPeloNome(String nome) {
		
		Funcionario f = funcionarios.stream().filter(x->x.getNome().equals(nome)).findFirst().orElse(null);
		
		return f;
	}
	
	public static List<Funcionario> buscaPeloSexo(String sexo) {
		
		List<Funcionario> f = funcionarios.stream().filter(x->x.getSexo().equals(sexo)).collect(Collectors.toList());

		return f;
	}
	
	public static Double somaSalarios() {
		
		Double total = funcionarios.stream().filter(x->x.getSalario()>500.)
				.map(z->z.getSalario()).reduce(0.0,(x,y)->x+y);
		
		return total;
	}
	
	public static void print() {
		
		funcionarios.stream().forEach(x->System.out.println());
	}
	
	public static void main(String[] args) {

		System.out.println(buscaPeloSexo("Masc"));
		System.out.println(somaSalarios());
	}
}
